#!/bin/bash
#michael hug
#mrhhug@gmail.com

device=$(ls -t /dev/tty* | head -1);
stty -F $device  cs8 9600 ignbrk -brkint -imaxbel -opost -onlcr -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke noflsh -ixon -crtscts
echo $device;
cat $device;
