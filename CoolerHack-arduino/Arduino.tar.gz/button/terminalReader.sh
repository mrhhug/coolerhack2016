#!/bin/bash
#michael hug
#mrhhug@gmail.com

device=$(ls -t /dev/tty* | head -1);
stty -F $device 9600 cs8 cread clocal
while true; do
	cat $device;
done
